---
name: research-report
description: >-
  把一个调研性问题综合成结构化、带 [cN] 引用溯源的 HTML 调研报告页。先用检索工具在知识库内
  广泛取证（可多文档），再按「摘要→背景→分主题论述→横向对比→结论与不确定性→参考清单」
  组织成完整 HTML 文档。当用户要求"调研/综述/汇总/出一份报告/系统梳理某主题"时加载。
version: 1.1.0
metadata:
  tags: [research, report, multi-doc, citation, synthesis, html]
  category: research
  requires_tools: [search_knowledge_base, read_chunks]
---

# 调研报告生成

## When to Use

当用户的诉求是「**综合性梳理 / 调研 / 综述 / 汇总成一份报告**」而非单点问答时加载本技能，例如：

- "帮我调研一下 X，出一份报告"
- "把知识库里关于 Y 的内容系统梳理一下"
- "对比一下这几篇文档在 Z 上的异同并总结"

普通单点事实问答**不要**加载本技能，直接回答即可。

## Procedure

1. **拆解主题**：把用户问题拆成 3~6 个子主题/调研维度，明确报告范围。
2. **广泛取证**：对每个子主题用 `search_knowledge_base` 检索（可用不同角度多次检索）；
   命中文档后，必要时用 `drill_down` / `skeleton` 定位章节，用 `read_chunks` 取关键片段全文。
   - 证据要覆盖多文档；注意去重与时效（同一事实有新旧版本时优先新的，并在报告中标注）。
3. **加载 HTML 模板（必选）**：
   - `skill_view(name="research-report", path="templates/report.html")` — 最终交付物的 HTML 骨架与样式；
   - （可选）`skill_view(name="research-report", path="templates/report-outline.md")` — 内容组织提纲。
4. **综合成 HTML 报告**，严格按下列结构填充 `report.html` 骨架中的对应区块：
   1. **摘要**（`#summary`）：3~5 句，结论先行。
   2. **背景与范围**（`#background`）：本报告调研了什么、覆盖哪些来源。
   3. **分主题论述**（`#topics`）：每个子主题一节；**每条论断后标注引用**，格式为
      `<a class="citation" href="#ref-cN">[cN]</a>`，可多标 `[c1][c3]`。
   4. **横向对比 / 关键发现**（`#comparison`）：信息适合对比时用 HTML 表格。
   5. **结论与不确定性**（`#conclusion`）：给出结论；证据不足处**明确写「知识库未覆盖」**，不得编造。
   6. **参考片段**（`#references`）：列出报告中用到的每个 `cN` 对应的来源文档/章节，
      并为每条引用提供 `<span id="ref-cN">` 锚点。
5. **输出最终 HTML**：在对话中输出**完整 HTML 文档**（从 `<!DOCTYPE html>` 到 `</html>`），
   可直接被前端 ReportViewer 渲染。HTML 前可有一两句过渡说明，但**主体必须是完整 HTML**。
6. **自检**（见 Verification）后再输出最终报告。

## Pitfalls

- **不要凭空编造引用号**：`cN` 必须确实来自工具返回结果；不确定就不标，绝不杜撰。
- **不要只检索一次就下笔**：调研报告需要多角度、多文档取证；但也要**适可而止**，证据足够即停，避免无意义反复检索。
- **不要把 preview 当全文**：`search_knowledge_base` 等返回的是约 200 字预览；关键论据被截断时用 `read_chunks` 取全文再引用。
- **不要输出 Markdown 代替 HTML 报告**：最终交付物必须是完整 HTML 页面，不是 markdown 六段式气泡。
- **HTML 必须闭合**：必须包含 `<!DOCTYPE html>` 与 `</html>`；禁止只输出 HTML 片段或省略闭合标签。
- **引用链接格式**：正文引用用 `<a class="citation" href="#ref-cN">[cN]</a>`；参考文献区用 `<span id="ref-cN">`。
- **公式格式**（若报告含公式）：行内 `$...$`、块级 `$$...$$`，禁用 `\( \)` / `\[ \]`。
- **范围守卫**：folder/单文档会话下，只在允许范围内取证，越界文档会被服务端拒绝。
- **本期不导出文件**：直接在对话里输出 HTML 报告，不要尝试生成 .docx/.pdf（暂无导出工具）。

## Verification

输出前逐项确认：

- [ ] 每个子主题都有至少一条带 `[cN]` 的证据支撑？
- [ ] 所有 `cN` 都真实出现在工具返回结果里，无杜撰？
- [ ] 证据不足的部分是否如实标注「知识库未覆盖」？
- [ ] 报告结构完整（摘要/背景/论述/对比/结论/参考）？
- [ ] 输出是否为**完整 HTML 文档**（`<!DOCTYPE html>` … `</html>`）？
- [ ] 正文引用是否为 `<a class="citation" href="#ref-cN">` 格式？
- [ ] 参考文献区是否包含对应的 `<span id="ref-cN">` 锚点？
