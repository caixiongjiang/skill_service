---
name: research-report
description: >-
  把一个调研性问题综合成结构化、带 [cN] 引用溯源的调研报告。先用检索工具在知识库内
  广泛取证（可多文档），再按「摘要→背景→分主题论述→横向对比→结论与不确定性→参考清单」
  组织成报告。当用户要求"调研/综述/汇总/出一份报告/系统梳理某主题"时加载。
version: 2.0.0
metadata:
  tags: [research, report, multi-doc, citation, synthesis]
  category: research
  requires_tools: [search_knowledge_base, read_chunks]
---

# 调研报告生成

## When to Use

当用户的诉求是「**综合性梳理 / 调研 / 综述 / 汇总成一份报告**」而非单点问答时加载本技能，例如：

- "帮我调研一下 X，出一份报告"
- "把知识库里关于 Y 的内容系统梳理一下"
- "对比一下这几篇文档在 Z 上的异同并总结"

普通单点事实问答**不要**加载本技能，直接回答即可。

## Procedure

1. **拆解主题**：把用户问题拆成 3~6 个子主题/调研维度，明确报告范围。
2. **广泛取证**：对每个子主题用 `search_knowledge_base` 检索（可用不同角度多次检索）；
   命中文档后，必要时用 `drill_down` / `skeleton` 定位章节，用 `read_chunks` 取关键片段全文。
   - 证据要覆盖多文档；注意去重与时效（同一事实有新旧版本时优先新的，并在报告中标注）。
3. **（可选）取结构模板**：`skill_view(name="research-report", path="templates/report-outline.md")`。
4. **输出 HTML 报告**（见下方格式要求）。
5. **自检**（见 Verification）后再输出最终报告。

## 输出格式要求

**必须输出完整的 HTML 页面**，不要输出 markdown。HTML 需包含内联 CSS 样式，可直接在浏览器中渲染。

### HTML 结构模板

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>调研报告：{主题}</title>
  <style>
    /* 基础样式 */
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      line-height: 1.8;
      color: #1a1a2e;
      background: #f8f9fa;
      padding: 2rem;
    }
    .container { max-width: 900px; margin: 0 auto; background: #fff; border-radius: 12px; box-shadow: 0 2px 12px rgba(0,0,0,0.08); padding: 3rem; }

    /* 头部 */
    .report-header { border-bottom: 2px solid #e9ecef; padding-bottom: 1.5rem; margin-bottom: 2rem; }
    .report-header h1 { font-size: 1.8rem; color: #2d3436; margin-bottom: 0.5rem; }
    .meta { font-size: 0.85rem; color: #6c757d; }
    .meta span { margin-right: 1.5rem; }

    /* 摘要 */
    .executive-summary { background: #f0f7ff; border-left: 4px solid #3b82f6; padding: 1.2rem 1.5rem; border-radius: 0 8px 8px 0; margin-bottom: 2rem; }
    .executive-summary h2 { font-size: 1rem; color: #3b82f6; margin-bottom: 0.5rem; }

    /* 目录 */
    .toc { background: #f8f9fa; border: 1px solid #e9ecef; border-radius: 8px; padding: 1.2rem 1.5rem; margin-bottom: 2rem; }
    .toc h2 { font-size: 1rem; margin-bottom: 0.8rem; color: #495057; }
    .toc ol { padding-left: 1.5rem; }
    .toc li { margin-bottom: 0.3rem; }
    .toc a { color: #3b82f6; text-decoration: none; }
    .toc a:hover { text-decoration: underline; }

    /* 章节 */
    .section { margin-bottom: 2rem; }
    .section h2 { font-size: 1.3rem; color: #2d3436; border-bottom: 1px solid #e9ecef; padding-bottom: 0.5rem; margin-bottom: 1rem; }
    .section h3 { font-size: 1.1rem; color: #495057; margin: 1.2rem 0 0.6rem; }
    .section p, .section li { margin-bottom: 0.5rem; }

    /* 引用 */
    .citation {
      display: inline-block;
      background: #e8f4fd;
      color: #2563eb;
      font-size: 0.75rem;
      padding: 0.1rem 0.4rem;
      border-radius: 4px;
      cursor: pointer;
      text-decoration: none;
      vertical-align: super;
    }
    .citation:hover { background: #bfdbfe; }

    /* 表格 */
    table { width: 100%; border-collapse: collapse; margin: 1rem 0; font-size: 0.9rem; }
    th, td { border: 1px solid #dee2e6; padding: 0.6rem 0.8rem; text-align: left; }
    th { background: #f1f3f5; font-weight: 600; }
    tr:nth-child(even) { background: #f8f9fa; }

    /* 结论 */
    .conclusion { background: #fff8e1; border-left: 4px solid #f59e0b; padding: 1.2rem 1.5rem; border-radius: 0 8px 8px 0; margin-bottom: 2rem; }
    .conclusion h2 { font-size: 1.1rem; color: #b45309; margin-bottom: 0.8rem; }
    .uncertainty { color: #dc2626; font-weight: 500; }

    /* 参考文献 */
    .references { margin-top: 2rem; }
    .references h2 { font-size: 1.1rem; margin-bottom: 1rem; }
    .ref-item { padding: 0.8rem; background: #f8f9fa; border-radius: 6px; margin-bottom: 0.5rem; font-size: 0.85rem; }
    .ref-id { font-weight: 600; color: #3b82f6; margin-right: 0.5rem; }
    .ref-source { color: #6c757d; }
    .ref-preview { margin-top: 0.3rem; color: #495057; font-style: italic; }
  </style>
</head>
<body>
  <div class="container">
    <!-- 报告头部 -->
    <div class="report-header">
      <h1>调研报告：{主题}</h1>
      <div class="meta">
        <span>📅 生成时间：{日期}</span>
        <span>📚 覆盖文档：{N} 篇</span>
        <span>🔍 检索策略：{策略说明}</span>
      </div>
    </div>

    <!-- 摘要 -->
    <div class="executive-summary">
      <h2>📋 摘要</h2>
      <p>3~5 句，结论先行。</p>
    </div>

    <!-- 目录 -->
    <div class="toc">
      <h2>📑 目录</h2>
      <ol>
        <li><a href="#section-1">子主题 A</a></li>
        <li><a href="#section-2">子主题 B</a></li>
        <li><a href="#comparison">横向对比</a></li>
        <li><a href="#conclusion">结论与不确定性</a></li>
        <li><a href="#references">参考文献</a></li>
      </ol>
    </div>

    <!-- 分主题论述 -->
    <div class="section" id="section-1">
      <h2>1. 子主题 A</h2>
      <p>论点内容 <a class="citation" href="#ref-c1">[c1]</a></p>
      <p>更多内容 <a class="citation" href="#ref-c2">[c2]</a><a class="citation" href="#ref-c3">[c3]</a></p>
    </div>

    <!-- 横向对比 -->
    <div class="section" id="comparison">
      <h2>横向对比</h2>
      <table>
        <thead><tr><th>维度</th><th>方案 A</th><th>方案 B</th></tr></thead>
        <tbody>
          <tr><td>维度 1</td><td>内容 <a class="citation" href="#ref-c1">[c1]</a></td><td>内容 <a class="citation" href="#ref-c2">[c2]</a></td></tr>
        </tbody>
      </table>
    </div>

    <!-- 结论 -->
    <div class="conclusion" id="conclusion">
      <h2>📌 结论与不确定性</h2>
      <ul>
        <li>结论 1</li>
        <li class="uncertainty">⚠️ 知识库未覆盖：不确定 1</li>
      </ul>
    </div>

    <!-- 参考文献 -->
    <div class="references" id="references">
      <h2>📖 参考文献</h2>
      <div class="ref-item" id="ref-c1">
        <span class="ref-id">[c1]</span>
        <span class="ref-source">文档名 - 章节</span>
        <div class="ref-preview">原文片段预览...</div>
      </div>
    </div>
  </div>
</body>
</html>
```

## Pitfalls

- **不要输出 markdown**：必须输出完整 HTML 页面，以 `<!DOCTYPE html>` 开头。
- **不要凭空编造引用号**：`cN` 必须确实来自工具返回结果；不确定就不标，绝不杜撰。
- **不要只检索一次就下笔**：调研报告需要多角度、多文档取证；但也要**适可而止**，证据足够即停。
- **不要把 preview 当全文**：`search_knowledge_base` 等返回的是约 200 字预览；关键论据被截断时用 `read_chunks` 取全文再引用。
- **公式格式**：行内 `$...$`、块级 `$$...$$`，禁用 `\( \)` / `\[ \]`。
- **引用链接必须可用**：每个 `[cN]` 必须是 `<a class="citation" href="#ref-cN">[cN]</a>`，对应参考文献区的 `id="ref-cN"`。
- **不要包含外部资源**：所有样式必须内联，不引用外部 CSS/JS/字体文件。

## Verification

输出前逐项确认：

- [ ] 输出的是完整 HTML（以 `<!DOCTYPE html>` 开头）？
- [ ] 每个子主题都有至少一条带 `[cN]` 引用的证据支撑？
- [ ] 所有 `cN` 都真实出现在工具返回结果里，无杜撰？
- [ ] 引用链接 `[cN]` 可跳转到参考文献区的对应条目？
- [ ] 证据不足的部分是否如实标注「知识库未覆盖」？
- [ ] 报告结构完整（摘要/目录/论述/对比/结论/参考）？
- [ ] 样式内联，无外部依赖？
